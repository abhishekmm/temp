﻿$(document).ready(function () {
	var arr1 = [{
		"title" : "ABC",
		"subtitle": "FHG",
		"content": "KKKK"
	},{
		"title" : "ABC",
		"subtitle": "FHG",
		"content": "KKKK"
	}]
	var powdery_mildew_arr= [{
		"title" : "Disease- Powdery Mild Detected ",
		"subtitle": "Following measure are  recommended by the  system to mitigate the damage",
		"content": "Green Cure Fungicide contains a patented formula of potassium bicarbonate — commonly used in food products — that kills many plant diseases on contact and provides up to 2 weeks of residual protection. At first sign of disease, mix 1-2 Tbsp/ gallon of water and apply to all exposed surfaces of the plant"
	}]
	
    fireblight_arr=[{
		"title" : "Disease- Fire Blight",
		"subtitle": "Following measure are  recommended by the  system to mitigate the damage",
		"content": "Bacterial spread can be reduced by applications of products that contain Streptomyces lydicus as the active ingredient. To obtain best disease control, applications should be made at the start of the bloom period and every five to seven days thereafter."
	}]
	
	apple_scab_arr=[{
		"title" : "Disease- Apple Scab",
		"subtitle": "Following measure are  recommended by the  system to mitigate the damage",
		"content": " Water in the evening or early morning hours (avoid overhead irrigation) to give the leaves time to dry out before infection can occur.Spread a 3- to 6-inch layer of compost under trees, keeping it away from the trunk, to cover soil and prevent splash dispersal of the fungal spores."
	}]
	
	rust_arr=[{
		"title" : "Disease- Rust",
		"subtitle": "Following measure are  recommended by the  system to mitigate the damage",
		"content": " rust can be controlled by spraying plants with a copper solution (0.5 to 2.0 oz/ gallon of water) at least four times between late August and late October."
	}]
	
	
	
	healthy_apple_plant=[{
		"title" : "Plant is healthy",
		"subtitle": "Following fertilizers can  be  used to the yield",
		"content": "Use organic fertilizers"
	}]

    $("#btnSubmit").click(function (event) {

        //stop submit the form, we will post it manually.
        event.preventDefault();

        // Get form
        var form = $('#fileUploadForm')[0];

        // Create an FormData object
        var data = new FormData(form);

        // If you want to add an extra field for the FormData
        //data.append("CustomField", "This is some extra data, testing");

        // disabled the submit button
        $("#btnSubmit").prop("disabled", true);

        $.ajax({
            type: "POST",
            enctype: 'multipart/form-data',
            url: "http://localhost:3003/index.html",
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            timeout: 600000,
            success: function (data) {
				console.log(data)


                //$("#result").innerHTML(data);
                document.getElementById("result").innerHTML = data;
				var Row = document.getElementById("row_1");
				console.log(Row);
                var Cells = Row.getElementsByTagName("td");
				console.log(Cells)
				var recommend=Cells[0].innerText;
				let filePath = $('#fileUrl').attr('src');
				switch((recommend.toLowerCase())){
					case 'diseased powdery mildew':{
						cropObj.loadData(powdery_mildew_arr,filePath);
						break;
					}
					case 'diseased fireblight': {
						cropObj.loadData(fireblight_arr,filePath);
						break;
					}
					case 'diseased apple scab': {
						cropObj.loadData(apple_scab_arr,filePath);
						break;
					}
					case 'diseased rust': {
						cropObj.loadData(rust_arr,filePath);
						break;
					}
					case 'healthy apple plant': {
						cropObj.loadData(healthy_apple_plant,filePath);
						break;
					}
				}
                
				
                
                console.log("SUCCESS : ", data);
                $("#btnSubmit").prop("disabled", false);

            },
            error: function (e) {

                $("#result").text("No data found, please try again.");
                console.log("ERROR : ", e);
                $("#btnSubmit").prop("disabled", false);

            }
        });

    });

});

var cropObj = {
    readURL : function(input) {
		$('#formData').html('');
		$('#fileUrl').addClass('imageStyle');
        document.getElementById("result").innerHTML = "";
            if (input.files && input.files[0]) {
                var reader = new FileReader();
    
                reader.onload = function (e) {
                    $('.uploadPreview')
                        .attr('src', e.target.result)
                        .width(150)
                        .height(260);
                };
    
            reader.readAsDataURL(input.files[0]);
			$('#healthyId').addClass('hide');
			$('#diseaseId').addClass('hide');
        }
		
    },
	loadData: function(data,path){
		let content = '';
		$('#form_data_id').empty();
		
		content += '<div class="diseased" id = "diseaseId">';
		
		$.each(data, function(key, value){
			content += '<div class="formHeader">'+value.title+'</div><div class="row formValue"><div class="col-md-4">';
			content += '<img class="uploadPreview" name="uploadPreview" src="'+path+'"/></div><div class="col-md-8 content">';
			content += '<div class="value_header">'+value.subtitle+'</div>';
			content += '<div class="value_text">'+value.content+'</div>';
			content += '</div></div>';
		});
		content += '</div>';
		
		$('#form_data_id').append(content);
	}

}