# Method 3 Transfer Learning

In command line, enter: 

`python label_image.py Testdata/Ragdoll_from_Gatil_Ragbelas.jpg`

This will predict test images using the model we have trained. 

The details about TensorFlow Transfer learning see here: https://www.tensorflow.org/tutorials/image_retraining